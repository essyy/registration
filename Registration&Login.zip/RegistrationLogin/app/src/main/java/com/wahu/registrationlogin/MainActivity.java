package com.wahu.registrationlogin;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.wahu.registrationlogin.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Submitted(View view) {
    }

    public void ShowTimePickerDialog(View view) {
    }

    public void movetologin(View view) {
        Intent movetologin = new Intent(this, LoginActivity.class);
        startActivity(movetologin);
    }

    public void movetogin(View view) {
    }
}